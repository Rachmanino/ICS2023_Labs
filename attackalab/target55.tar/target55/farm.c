/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_156(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_420(unsigned x)
{
    return x + 3349760015U;
}

unsigned addval_457(unsigned x)
{
    return x + 3347663022U;
}

unsigned getval_461()
{
    return 2428995912U;
}

unsigned getval_455()
{
    return 2425379051U;
}

void setval_496(unsigned *p)
{
    *p = 2425394264U;
}

unsigned getval_282()
{
    return 405033255U;
}

unsigned addval_185(unsigned x)
{
    return x + 3284633864U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_225(unsigned *p)
{
    *p = 2425542281U;
}

void setval_427(unsigned *p)
{
    *p = 2425408137U;
}

unsigned getval_298()
{
    return 2463533418U;
}

unsigned getval_460()
{
    return 3227568777U;
}

void setval_136(unsigned *p)
{
    *p = 3771287624U;
}

void setval_275(unsigned *p)
{
    *p = 3676357000U;
}

void setval_412(unsigned *p)
{
    *p = 3682915977U;
}

unsigned getval_200()
{
    return 3353381192U;
}

unsigned addval_438(unsigned x)
{
    return x + 3286288712U;
}

void setval_351(unsigned *p)
{
    *p = 3281046153U;
}

unsigned addval_164(unsigned x)
{
    return x + 3523789193U;
}

unsigned addval_213(unsigned x)
{
    return x + 3224423049U;
}

void setval_380(unsigned *p)
{
    *p = 3600362443U;
}

unsigned addval_368(unsigned x)
{
    return x + 3232025225U;
}

void setval_168(unsigned *p)
{
    *p = 3374366985U;
}

void setval_204(unsigned *p)
{
    *p = 3281043849U;
}

void setval_139(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_367(unsigned x)
{
    return x + 3221277321U;
}

void setval_190(unsigned *p)
{
    *p = 2430634314U;
}

void setval_153(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_334(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_230()
{
    return 2425411225U;
}

unsigned getval_279()
{
    return 3269495112U;
}

unsigned getval_218()
{
    return 3599314394U;
}

unsigned addval_485(unsigned x)
{
    return x + 3376993929U;
}

unsigned addval_364(unsigned x)
{
    return x + 3375939981U;
}

unsigned getval_285()
{
    return 3682124169U;
}

void setval_411(unsigned *p)
{
    *p = 3676886665U;
}

void setval_102(unsigned *p)
{
    *p = 2425405849U;
}

unsigned getval_255()
{
    return 3348155017U;
}

unsigned addval_189(unsigned x)
{
    return x + 3526937217U;
}

unsigned addval_435(unsigned x)
{
    return x + 2445379882U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
